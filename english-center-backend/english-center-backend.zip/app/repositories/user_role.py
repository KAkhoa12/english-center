from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import UserRole
from app.repositories.base import BaseRepository


class UserRoleRepository(BaseRepository[UserRole]):
    def __init__(self, db: Session) -> None:
        super().__init__(db, UserRole)

    def get_active_relation(self, user_id: str, role_id: str) -> UserRole | None:
        return self.db.execute(
            select(UserRole).where(
                UserRole.user_id == user_id,
                UserRole.role_id == role_id,
                UserRole.deleted_at.is_(None),
            )
        ).scalar_one_or_none()

    def create_relation(self, user_id: str, role_id: str) -> UserRole:
        relation = UserRole(user_id=user_id, role_id=role_id)
        self.db.add(relation)
        self.db.flush()
        return relation

    def list_active_role_ids_by_user_id(self, user_id: str) -> list[str]:
        return list(
            self.db.execute(
                select(UserRole.role_id).where(
                    UserRole.user_id == user_id,
                    UserRole.deleted_at.is_(None),
                )
            ).scalars().all()
        )
