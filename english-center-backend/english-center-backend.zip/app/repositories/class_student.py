from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.models.class_student import ClassEnrollmentStatus, ClassStudent
from app.repositories.base import BaseRepository


class ClassStudentRepository(BaseRepository[ClassStudent]):
    def __init__(self, db: Session) -> None:
        super().__init__(db, ClassStudent)

    def get_by_class_and_student(self, class_id: str, student_id: str) -> ClassStudent | None:
        return self.db.execute(
            select(ClassStudent).where(
                ClassStudent.class_id == class_id,
                ClassStudent.student_id == student_id,
                ClassStudent.deleted_at.is_(None),
            )
        ).scalar_one_or_none()

    def list_by_class_id(self, class_id: str) -> list[ClassStudent]:
        return list(
            self.db.execute(
                select(ClassStudent).where(
                    ClassStudent.class_id == class_id,
                    ClassStudent.deleted_at.is_(None),
                )
            ).scalars().all()
        )

    def list_by_student_id(self, student_id: str) -> list[ClassStudent]:
        return list(
            self.db.execute(
                select(ClassStudent).where(
                    ClassStudent.student_id == student_id,
                    ClassStudent.deleted_at.is_(None),
                )
            ).scalars().all()
        )

    def count_active_students(self, class_id: str) -> int:
        return int(
            self.db.execute(
                select(func.count())
                .select_from(ClassStudent)
                .where(
                    ClassStudent.class_id == class_id,
                    ClassStudent.deleted_at.is_(None),
                    ClassStudent.enrollment_status.notin_([ClassEnrollmentStatus.cancelled, ClassEnrollmentStatus.dropped]),
                )
            ).scalar_one()
        )
