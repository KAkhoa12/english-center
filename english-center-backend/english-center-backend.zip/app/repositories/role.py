from sqlalchemy import select
from sqlalchemy.orm import Session
from app.repositories.base import BaseRepository
from app.models import Role


class RoleRepository(BaseRepository[Role]):
    def __init__(self, db: Session) -> None:
        super().__init__(db, Role)

    def get_active_by_ids(self, role_ids: list[str]) -> list[Role]:
        return list(
            self.db.execute(
                select(Role).where(Role.id.in_(role_ids), Role.deleted_at.is_(None))
            ).scalars().all()
        )

    def list_active_role_names_by_ids(self, role_ids: list[str]) -> list[str]:
        if not role_ids:
            return []
        return list(
            self.db.execute(
                select(Role.name).where(Role.id.in_(role_ids), Role.deleted_at.is_(None))
            ).scalars().all()
        )
