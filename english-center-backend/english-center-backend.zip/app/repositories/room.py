from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.room import Room
from app.repositories.base import BaseRepository


class RoomRepository(BaseRepository[Room]):
    def __init__(self, db: Session) -> None:
        super().__init__(db, Room)

    def get_by_name(self, name: str) -> Room | None:
        return self.db.execute(
            select(Room).where(Room.name == name, Room.deleted_at.is_(None))
        ).scalar_one_or_none()

    def get_active_by_id(self, room_id: str) -> Room | None:
        return self.get(room_id)
