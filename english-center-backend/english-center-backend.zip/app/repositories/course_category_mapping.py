from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models.course import CourseCategory, CourseCategoryMapping
from app.repositories.base import BaseRepository


class CourseCategoryMappingRepository(BaseRepository[CourseCategoryMapping]):
    def __init__(self, db: Session) -> None:
        super().__init__(db, CourseCategoryMapping)

    def get_active_by_course_id(self, course_id: str) -> list[CourseCategoryMapping]:
        return list(
            self.db.execute(
                select(CourseCategoryMapping).where(
                    CourseCategoryMapping.course_id == course_id,
                    CourseCategoryMapping.deleted_at.is_(None),
                )
            ).scalars().all()
        )

    def get_relation(self, course_id: str, category_id: str) -> CourseCategoryMapping | None:
        return self.db.execute(
            select(CourseCategoryMapping).where(
                CourseCategoryMapping.course_id == course_id,
                CourseCategoryMapping.category_id == category_id,
            )
        ).scalar_one_or_none()

    def get_categories_by_course_id(self, course_id: str) -> list[CourseCategory]:
        return list(
            self.db.execute(
                select(CourseCategory)
                .join(CourseCategoryMapping, CourseCategoryMapping.category_id == CourseCategory.id)
                .where(
                    CourseCategoryMapping.course_id == course_id,
                    CourseCategoryMapping.deleted_at.is_(None),
                    CourseCategory.deleted_at.is_(None),
                )
            ).scalars().all()
        )
