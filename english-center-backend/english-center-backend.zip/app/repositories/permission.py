from sqlalchemy import select
from sqlalchemy.orm import Session

from app.models import Permission
from app.repositories.base import BaseRepository


class PermissionRepository(BaseRepository[Permission]):
    def __init__(self, db: Session) -> None:
        super().__init__(db, Permission)

    def code_exists(self, code: str, exclude_permission_id: str | None = None) -> bool:
        stmt = select(Permission.id).where(
            Permission.code == code,
            Permission.deleted_at.is_(None),
        )
        if exclude_permission_id is not None:
            stmt = stmt.where(Permission.id != exclude_permission_id)
        return self.db.execute(stmt).first() is not None

    def get_by_code(self, code: str, include_deleted: bool = False) -> Permission | None:
        stmt = select(Permission).where(Permission.code == code)
        if not include_deleted:
            stmt = stmt.where(Permission.deleted_at.is_(None))
        return self.db.execute(stmt).scalar_one_or_none()

    def get_active_by_ids(self, permission_ids: list[str]) -> list[Permission]:
        return list(
            self.db.execute(
                select(Permission).where(
                    Permission.id.in_(permission_ids),
                    Permission.deleted_at.is_(None),
                )
            ).scalars().all()
        )

    def list_active_codes_by_ids(self, permission_ids: list[str]) -> list[str]:
        if not permission_ids:
            return []
        return list(
            self.db.execute(
                select(Permission.code).where(
                    Permission.id.in_(permission_ids),
                    Permission.deleted_at.is_(None),
                )
            ).scalars().all()
        )
