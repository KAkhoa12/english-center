from typing import TypedDict, Annotated, List, Optional, Dict, Any, Literal
from langchain_core.messages import BaseMessage
from langgraph.graph.message import add_messages

class AdvisorState(TypedDict):
    thread_id: Optional[str]
    client_message_id: Optional[str]
    messages: Annotated[list[BaseMessage], add_messages]
